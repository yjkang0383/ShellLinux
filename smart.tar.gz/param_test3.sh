#!/bin/sh

echo '$#(파라미터 개수) = '$# 
echo '$@ = '$@

