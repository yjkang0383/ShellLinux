#!/bin/bash


array=(100 samo 사모 400 500 600 700 800 900 1000) #배열 array 선언 및 초기화

echo $array			#배열 arrat의 array[0]
echo $array[0]
echo ${array[0]}
echo ${array[1]}
echo ${array[2]}
echo ${array[3]}
echo ${array[4]}
echo ${array[5]}
echo ${array[6]}
echo ${array[7]}
echo ${array[8]}
echo ${array[9]}
echo ${array[10]}

