#!/bin/sh
echo " 글자를 입력하시오. "
read INPUT_DATA
echo " 입력된 글자는 [${INPUT_DATA}] 입니다. "
