#!/bin/bash

for ((i=1; i<10; i++))
do #(
	number=`expr 5 \* $i`
	echo  " 5 * $i = $number"   
done #)

