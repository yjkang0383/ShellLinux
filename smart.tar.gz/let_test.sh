#!/bin/nash

let NUM1=37
let NUM1=NUM+10
echo "37 + 10 = $NUM1"
let "Num1=NUM1+10"
echo "47 + 10 = $NUM1"

let NUM2=16
let "NUM2 /=4"
echo "16/4 = $NUM2"
let "NUM2 -= 5"
echo "4 - 5 = $NUM2"

let NUM3=9
let "NUM3=NUM3*10"
echo "9*10= $NUM3"
let "NUM3 %= 8"
echo "90을 8로 나눈 나머지는 =$NUM3"
