#!/bin/sh
PATH_VAL="/home/bnk/code/home/bnk/code/bnk/code"
echo ${PATH_VAL%/bnk*}
echo ${PATH_VAL%%/bnk*}
echo ${PATH_VAL#/bnk*}
echo ${PATH_VAL##/bnk*}
