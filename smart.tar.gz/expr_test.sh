#!/bin/bash

echo `expr \( 3 + 2 \) \* \( 5 - 2 \)`
