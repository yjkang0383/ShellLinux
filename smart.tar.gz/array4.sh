#!/bin/bash

array=(100 samo 사모 "사모예드는 강아지" 500 600 700 800 900 1000)

echo array[0] = ${array[0]}
echo array[1] = ${array[1]}
echo array[2] = ${array[2]}
echo array[3] = ${array[3]}
echo array[4] = ${array[4]}
echo array[5] = ${array[5]}
echo array[6] = ${array[6]}
echo array[7] = ${array[7]}
echo array[8] = ${array[8]}
echo array[9] = ${array[9]}

