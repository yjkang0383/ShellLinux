#!/bin/sh

for VAL in $*
do
	echo "Arg = [$VAL]"
done
