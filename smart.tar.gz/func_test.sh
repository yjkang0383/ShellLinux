#!/bin/bash

function Normal
{
	echo "SAMOYED YOMI"
	return
}

Normal
Normal
Normal
Normal

